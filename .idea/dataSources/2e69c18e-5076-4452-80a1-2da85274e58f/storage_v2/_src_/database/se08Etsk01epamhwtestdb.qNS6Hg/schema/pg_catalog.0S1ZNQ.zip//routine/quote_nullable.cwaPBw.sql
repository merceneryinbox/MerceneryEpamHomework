CREATE FUNCTION quote_nullable(anyelement)
  RETURNS text
STABLE
PARALLEL SAFE
COST 1
LANGUAGE SQL
AS $$
select pg_catalog.quote_nullable($1::pg_catalog.text)
$$;

